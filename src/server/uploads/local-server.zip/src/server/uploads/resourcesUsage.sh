#! /bin/bash

echo "CPU Usage: "$[100-$(vmstat 1 2|tail -1|awk '{print $15}')]"%"

echo RAM Usage: $(free -m | awk 'NR==2{printf "%.2f%%\t\t", $3*100/$2 }')

